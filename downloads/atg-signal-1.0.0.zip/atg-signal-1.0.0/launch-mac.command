#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required to run ATG Signal."
  echo "Install Python 3 through your organisation's usual software process, then try again."
  exit 1
fi

exec python3 serve.py
