@echo off
setlocal
cd /d "%~dp0"

where py >NUL 2>NUL
if %ERRORLEVEL% EQU 0 (
  py -3 serve.py
  goto :end
)

where python >NUL 2>NUL
if %ERRORLEVEL% EQU 0 (
  python serve.py
  goto :end
)

echo Python 3 is required to run ATG Signal.
echo Install Python 3 through your organisation's usual software process, then try again.
pause

:end
endlocal
