#!/usr/bin/env python3
"""Loopback-only static server for the ATG Signal offline package."""

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Timer
import webbrowser


HOST = "127.0.0.1"
PORT = 8765
ROOT = Path(__file__).resolve().parent / "site"
URL = f"http://{HOST}:{PORT}/signal/"


class SignalRequestHandler(SimpleHTTPRequestHandler):
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        ".mjs": "text/javascript",
        ".webmanifest": "application/manifest+json",
    }

    def list_directory(self, path):
        self.send_error(403, "Directory listing is disabled")
        return None

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        super().end_headers()


def open_browser():
    webbrowser.open(URL)


def main():
    handler = partial(SignalRequestHandler, directory=str(ROOT))
    server = ThreadingHTTPServer((HOST, PORT), handler)
    browser_timer = Timer(0.8, open_browser)
    browser_timer.daemon = True
    browser_timer.start()
    print(f"ATG Signal is available at {URL}")
    print("Press Control+C to stop the local server.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
