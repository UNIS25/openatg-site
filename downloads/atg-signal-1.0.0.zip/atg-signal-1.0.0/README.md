# ATG Signal 1.0.0

ATG Signal identifies top-performing social media content, compares performance between
reporting periods, and generates Excel and Word reports in the browser.

Your selected files are processed on this device. OpenATG does not receive or store their
contents.

## Requirements

- A current desktop browser with JavaScript and the File API enabled.
- Python 3 to run the included local application server.
- No internet connection is required.

The server binds only to `127.0.0.1`, serves this package, and disables directory listings. It
does not upload files or provide an external network service.

## macOS

1. Extract `atg-signal-1.0.0.zip`.
2. Open Terminal and change to the extracted `atg-signal-1.0.0` folder.
3. Run `chmod +x launch-mac.command` once if the file is not already executable.
4. Run `./launch-mac.command`.
5. ATG Signal should open at `http://127.0.0.1:8765/signal/`. Open that address manually if
   your browser does not open automatically.
6. Press Control+C in Terminal to stop the local server.

If macOS blocks the launcher after download, use Control-click, choose Open, and confirm that
you want to open this local script.

## Windows

1. Use **Extract All** on `atg-signal-1.0.0.zip`.
2. Open the extracted `atg-signal-1.0.0` folder.
3. Double-click `launch-windows.cmd`.
4. ATG Signal should open at `http://127.0.0.1:8765/signal/`. Open that address manually if
   your browser does not open automatically.
5. Press Control+C in the Command Prompt window to stop the local server.

The Windows launcher first tries the `py -3` launcher, then `python`. If neither command is
available, install Python 3 through your organisation's usual software process.

## Linux

From the extracted folder, run `python3 serve.py`, then open
`http://127.0.0.1:8765/signal/`. Press Control+C to stop the server.

## Important

Do not open `site/signal/index.html` directly with a `file://` URL. ATG Signal uses browser ES
modules and a service worker, so the included local server is required.

The machine-readable application metadata is in `app-manifest.json`. File hashes are in
`SHA256SUMS.txt`. Third-party notices and full dependency licence texts are under
`site/signal/`.
